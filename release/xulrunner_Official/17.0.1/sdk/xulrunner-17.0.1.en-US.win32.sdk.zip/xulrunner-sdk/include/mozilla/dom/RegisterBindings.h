#ifndef mozilla_dom_RegisterBindings_h__
#define mozilla_dom_RegisterBindings_h__


namespace mozilla {
namespace dom {
void
Register(nsScriptNameSpaceManager* aNameSpaceManager);

} // namespace dom
} // namespace mozilla


#endif // mozilla_dom_RegisterBindings_h__
