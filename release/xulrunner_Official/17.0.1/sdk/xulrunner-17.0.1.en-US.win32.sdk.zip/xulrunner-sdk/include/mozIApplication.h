/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM e:/builds/moz2_slave/rel-m-rel-xr-w32-bld/build/dom/interfaces/apps/mozIApplication.idl
 */

#ifndef __gen_mozIApplication_h__
#define __gen_mozIApplication_h__


#ifndef __gen_nsIDOMApplicationRegistry_h__
#include "nsIDOMApplicationRegistry.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    mozIApplication */
#define MOZIAPPLICATION_IID_STR "8de25e36-b4cb-4e89-9310-a199dce4e5f4"

#define MOZIAPPLICATION_IID \
  {0x8de25e36, 0xb4cb, 0x4e89, \
    { 0x93, 0x10, 0xa1, 0x99, 0xdc, 0xe4, 0xe5, 0xf4 }}

class NS_NO_VTABLE mozIApplication : public mozIDOMApplication {
 public: 

  NS_DECLARE_STATIC_IID_ACCESSOR(MOZIAPPLICATION_IID)

  /* boolean hasPermission (in string permission); */
  NS_IMETHOD HasPermission(const char * permission, bool *_retval) = 0;

};

  NS_DEFINE_STATIC_IID_ACCESSOR(mozIApplication, MOZIAPPLICATION_IID)

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_MOZIAPPLICATION \
  NS_IMETHOD HasPermission(const char * permission, bool *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_MOZIAPPLICATION(_to) \
  NS_IMETHOD HasPermission(const char * permission, bool *_retval) { return _to HasPermission(permission, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_MOZIAPPLICATION(_to) \
  NS_IMETHOD HasPermission(const char * permission, bool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasPermission(permission, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public mozIApplication
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_MOZIAPPLICATION

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, mozIApplication)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* boolean hasPermission (in string permission); */
NS_IMETHODIMP _MYCLASS_::HasPermission(const char * permission, bool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_mozIApplication_h__ */
